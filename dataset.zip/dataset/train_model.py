import os
import sys
import pickle
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestRegressor

# Create dataset directory if not exists
os.makedirs('dataset', exist_ok=True)

# Create sample training data with all possible values from the form
np.random.seed(42)
n_samples = 5000

# All values from the HTML form
states = ['andaman and nicobar islands', 'andhra pradesh', 'arunachal pradesh', 'assam', 
          'bihar', 'chandigarh', 'chhattisgarh', 'dadra and nagar haveli', 'goa', 
          'gujarat', 'haryana', 'himachal pradesh', 'jammu and kashmir', 'jharkhand', 
          'karnataka', 'kerala', 'madhya pradesh', 'maharashtra', 'manipur', 
          'meghalaya', 'mizoram', 'nagaland', 'odisha', 'puducherry', 'punjab', 
          'rajasthan', 'sikkim', 'tamil nadu', 'telangana', 'tripura', 
          'uttar pradesh', 'uttarakhand', 'west bengal']

crop_types = ['kharif', 'rabi', 'whole year', 'summer']

crops = ['rice', 'turmeric', 'sweetpotato', 'moong', 'maize', 'cashewnuts', 'blackpepper',
         'arecanut', 'pumpkin', 'cardamom', 'soyabean', 'banana', 'brinjal', 'grapes',
         'orange', 'tapioca', 'ladyfinger', 'barley', 'drumstick', 'jute', 'sunflower',
         'apple', 'jackfruit', 'bottlegourd', 'cotton', 'coffee', 'sesamum', 'garlic',
         'potato', 'beetroot', 'onion', 'rapeseed', 'horsegram', 'ragi', 'jowar',
         'wheat', 'coriander', 'ginger', 'cabbage', 'mango', 'tomato', 'cucumber',
         'papaya', 'ridgegourd', 'bittergourd', 'cauliflower', 'ashgourd', 'pomegranate',
         'watermelon', 'carrot', 'blackgram', 'radish', 'pineapple']

data = {
    'N': np.random.uniform(0, 200, n_samples),
    'P': np.random.uniform(0, 150, n_samples),
    'K': np.random.uniform(0, 200, n_samples),
    'pH': np.random.uniform(4.5, 9.0, n_samples),
    'rainfall': np.random.uniform(50, 300, n_samples),
    'temperature': np.random.uniform(10, 45, n_samples),
    'Area_in_hectares': np.random.uniform(0.1, 100, n_samples),
    'State_Name': np.random.choice(states, n_samples),
    'Crop_Type': np.random.choice(crop_types, n_samples),
    'Crop': np.random.choice(crops, n_samples),
    'Production': np.random.uniform(1, 1000, n_samples)  # Target variable
}

df = pd.DataFrame(data)

# Encode categorical variables (store mapping for inference)
le_state = LabelEncoder()
le_croptype = LabelEncoder()
le_crop = LabelEncoder()

df['State_Name'] = le_state.fit_transform(df['State_Name'])
df['Crop_Type'] = le_croptype.fit_transform(df['Crop_Type'])
df['Crop'] = le_crop.fit_transform(df['Crop'])

# Save encoders for later use
encoders = {
    'State_Name': le_state,
    'Crop_Type': le_croptype,
    'Crop': le_crop
}

# Prepare features and target
X = df.drop('Production', axis=1)
y = df['Production']

# Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train a simple model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_scaled, y)

# Save the preprocessor (scaler + encoders)
preprocessor = {
    'scaler': scaler,
    'encoders': encoders,
    'feature_columns': list(X.columns)
}

# Save model and preprocessor
with open('dataset/preprocessor.pkl', 'wb') as f:
    pickle.dump(preprocessor, f)

with open('dataset/model.pkl', 'wb') as f:
    pickle.dump(model, f)

print("Model files created successfully!")
print("- dataset/preprocessor.pkl")
print("- dataset/model.pkl")
print(f"\nState Names: {list(le_state.classes_)}")
print(f"Crop Types: {list(le_croptype.classes_)}")
print(f"Crops: {list(le_crop.classes_)}")
